(function(window, undefined) {

  var jimLinks = {
    "724d6129-a5ed-4b21-a1a7-3ef200a06710" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Line_2" : [
        "c059d41f-6c0e-4b56-a064-91bd05da5a78"
      ]
    },
    "883aed0b-77af-4e79-a3c7-3b701ac93f7d" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_28" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ]
    },
    "f3a3edb4-1297-4c0d-96d4-2c1ec9870070" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_28" : [
        "ed74f470-4343-4380-a864-f8dbad599122"
      ]
    },
    "ed74f470-4343-4380-a864-f8dbad599122" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Line_2" : [
        "7198b126-8045-4499-9acf-878838131f88"
      ]
    },
    "a55013df-bea6-4693-86cc-1c4c6e922cbe" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Line_2" : [
        "f3a3edb4-1297-4c0d-96d4-2c1ec9870070"
      ]
    },
    "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ]
    },
    "8cbba4f8-8373-40d3-9672-c51ef00654fa" : {
      "Label_28" : [
        "a55013df-bea6-4693-86cc-1c4c6e922cbe"
      ],
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ]
    },
    "e92c9fb5-5803-4083-ae7c-cf8c435fc4e2" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Button_1" : [
        "8cbba4f8-8373-40d3-9672-c51ef00654fa"
      ]
    },
    "8a638ee1-d936-47c6-b4d7-1fa17ca84294" : {
      "Image_1" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_29" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ]
    },
    "95adc887-3e85-4566-95d6-d7b6077c8c85" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Button_1" : [
        "e92c9fb5-5803-4083-ae7c-cf8c435fc4e2"
      ]
    },
    "7198b126-8045-4499-9acf-878838131f88" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_28" : [
        "724d6129-a5ed-4b21-a1a7-3ef200a06710"
      ]
    },
    "6f7f7e16-6686-402a-94ad-a2c5a1160750" : {
      "Image_2" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ]
    },
    "70cd42b1-78db-4d0f-a724-9ca3d034a4c9" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_29" : [
        "a55013df-bea6-4693-86cc-1c4c6e922cbe"
      ]
    },
    "c059d41f-6c0e-4b56-a064-91bd05da5a78" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_28" : [
        "a55013df-bea6-4693-86cc-1c4c6e922cbe"
      ],
      "Label_32" : [
        "95adc887-3e85-4566-95d6-d7b6077c8c85"
      ]
    },
    "2e9426dc-03b4-4405-9be7-1bc23b03cf97" : {
    },
    "1e8a452c-0c3e-434b-9a69-9f88c989dab1" : {
    },
    "c5041d43-32bf-4cdb-9123-16f002dfc5d8" : {
      "Label_126" : [
        "825d8d4d-d97b-4a27-8c53-9894f5e6cd0b"
      ],
      "Label_185" : [
        "6f7f7e16-6686-402a-94ad-a2c5a1160750"
      ],
      "Label_20" : [
        "8a638ee1-d936-47c6-b4d7-1fa17ca84294"
      ],
      "Label_53" : [
        "883aed0b-77af-4e79-a3c7-3b701ac93f7d"
      ],
      "Label_272" : [
        "70cd42b1-78db-4d0f-a724-9ca3d034a4c9"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);