(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-724d6129-a5ed-4b21-a1a7-3ef200a06710 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-883aed0b-77af-4e79-a3c7-3b701ac93f7d .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-f3a3edb4-1297-4c0d-96d4-2c1ec9870070 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-ed74f470-4343-4380-a864-f8dbad599122 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-a55013df-bea6-4693-86cc-1c4c6e922cbe .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-825d8d4d-d97b-4a27-8c53-9894f5e6cd0b .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-8cbba4f8-8373-40d3-9672-c51ef00654fa .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-e92c9fb5-5803-4083-ae7c-cf8c435fc4e2 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-8a638ee1-d936-47c6-b4d7-1fa17ca84294 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-95adc887-3e85-4566-95d6-d7b6077c8c85 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-7198b126-8045-4499-9acf-878838131f88 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-6f7f7e16-6686-402a-94ad-a2c5a1160750 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-70cd42b1-78db-4d0f-a724-9ca3d034a4c9 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-c059d41f-6c0e-4b56-a064-91bd05da5a78 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);